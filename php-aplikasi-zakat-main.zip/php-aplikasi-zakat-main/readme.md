#Source code aplikasi zakat
Anggota:
- Muhamad Erik Setiawan (2222105129)
- Windy Wulandari (2222105220)
- Toibatul Sa'diah (2222105213)
- Tifani Aulia Rahmah (2222105212)
- Zahra Salma Hanifah (2222105228)

Teknologi:
- PHP
- Bootstrap
- MySql/MariaDB

User Login
username: admin
password: admin

link akses: localhost/zakat
